#include <iostream>
#include <chrono>
#include <random>
//#include "cpucounters.h"
#include <sys/stat.h>
//#include "tbb/tbb.h"
#include <cmath>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <limits.h>
#include <signal.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <vector>
#include <string.h>
#include <stdint.h>
#include <string>
#include <thread>
#include <atomic>
#include <immintrin.h>
#include "SSBTree.h"
#define test_num 1000000
#define test_thread 128
using namespace std;
using namespace thu_ltl;
#define TEST_LAYOUT_NAME "thu_ltl"
static inline int file_exists(char const *file)
{
    struct stat buffer;
    return stat(file, &buffer);
}

unsigned int levelmax;
uint64_t records[50000000]={0};
uint64_t record[test_thread][test_num]={0};
uint64_t latency[test_thread], insert_nb[test_thread] = {0},insert_nbs = 0;
__thread struct timespec T1[test_thread], T2[test_thread];
std::vector<uint64_t> buffer;
std::vector<uint64_t> sbuffer;
std::vector<long> slen;
std::vector<char> ops;
long sfencenum = 0;
long clwbnum = 0;
long splitnum = 0;
long alloer=0;
int initial=0;

void read_data_from_file(char* file)
{
    long count = 0;

    FILE* fp = fopen(file, "r");
    if (fp == NULL) {
        exit(-1);
    }
    buffer.clear();
    printf("reading\n");
    while (1) {
        uint64_t key;
        count = fscanf(fp, "%lld\n", &key);
        if (count != 1) {
            break;
        }
        buffer.push_back(key);
    }
    fclose(fp);
    printf("file closed\n");
}


void scan_data_from_file(char* file)
{
    long count = 0;

    FILE* fp = fopen(file, "r");
    if (fp == NULL) {
        exit(-1);
    }
    buffer.clear();
    ops.clear();
    printf("reading\n");
    while (1) {
        char str[100];
        char* p;
        count = fscanf(fp, "%s\n", str);
        if (count != 1) {
            break;
        }
        p = strtok(str, ",");
        buffer.push_back(atoll(p));
        p = strtok(NULL, ",");
        ops.push_back(p[0]);
    }
    fclose(fp);
    printf("file closed\n");
}

inline int64_t signextend(const uint64_t x)
{
    struct
    {
        int64_t x: 48;
    } s;
    return s.x = x;
}


void clear_cache() {
  // Remove cache
  int size = 256 * 1024 * 1024;
  char *garbage = new char[size];
  for (int i = 0; i < size; ++i)
    garbage[i] = i;
  for (int i = 100; i < size; ++i)
    garbage[i] += garbage[i - 100];
  delete[] garbage;
}

void sd_data_from_file(char* file)
{
    long count = 0;

    FILE* fp = fopen(file, "r");
    if (fp == NULL) {
        exit(-1);
    }
    buffer.clear();
    slen.clear();
    printf("reading\n");
    while (1) {
        char str[100];
        char* p;
        count = fscanf(fp, "%s\n", str);
        if (count != 1) {
            break;
        }
        p = strtok(str, ",");
        buffer.push_back(atoll(p));
        p = strtok(NULL, ",");
        slen.push_back(atol(p));
    }
    fclose(fp);
    printf("file closed\n");
}


void run(int argc, char **argv)
{
	/*
    std::cout << "Simple Eample of SSBTree" << std::endl;
    int n = std::atoll(argv[1]);
    uint64_t *keys = new uint64_t[n];

    for (int i = 0 ; i < n; i++)
    {
        keys[i] = i + 1;
    }
    */
    //int num_thread = 1;
    struct option long_options[] = {
        // These options don't set a flag
        {"help",                      no_argument,       NULL, 'h'},
        {"duration",                  required_argument, NULL, 'd'},
        {"initial-size",              required_argument, NULL, 'i'},
        {"thread-num",                required_argument, NULL, 't'},
        {"range",                     required_argument, NULL, 'r'},
        {"seed",                      required_argument, NULL, 'S'},
        {"update-rate",               required_argument, NULL, 'u'},
        {"unbalance",                 required_argument, NULL, 'U'},
        {"elasticity",                required_argument, NULL, 'x'},
        {NULL,                        0,                 NULL, 0  }
    };

        int i,c;
    long nb_threads;
   while(1) {
        i = 0;
        c = getopt_long(argc, argv, "hAf:d:i:t:r:S:u:U:c:", long_options, &i);
        if(c == -1) break;
        if(c == 0 && long_options[i].flag == 0) c = long_options[i].val;
        switch(c) {
                case 0:
                    break;
                case 't':
                    nb_threads = atoi(optarg);
                    break;
                default:
                    exit(1);
        }
    }

   //assert(nb_threads > 0);
   printf("Nb threads   : %d\n",  nb_threads);

    char pathname[100] = "/mnt/ext4/ssbtree/pool";
    SSBTree *KV =  nullptr;
    PMEMobjpool *pop;
    if (file_exists(pathname) != 0)
    {
        int sds_write_value = 0;
        pmemobj_ctl_set(NULL, "sds.at_create", &sds_write_value);
        if ((pop = pmemobj_create(pathname, POBJ_LAYOUT_NAME(TEST_LAYOUT_NAME),
                                  (uint64_t)200 * 1024 * 1024 * 1024, 0666)) == NULL)
        {
            printf("failed to create pool. path is : %s\n", pathname);
            //delete[] keys;
            return ;
        }
        TOID(SSBTree) sbt = POBJ_ROOT(pop, SSBTree);
        KV = D_RW(sbt);
        KV->reStart(pop);
    }
    else
    {

        if ((pop = pmemobj_open(pathname, POBJ_LAYOUT_NAME(TEST_LAYOUT_NAME))) == NULL)
        {
            printf("failed to open pool. path is : %s\n",pathname);
            //delete[] keys;
            return ;
        }
        TOID(SSBTree) sbt = POBJ_ROOT(pop, SSBTree);
        KV = D_RW(sbt);
        KV->reStart(pop);
        //delete[] keys;
        pmemobj_close(pop);
        return;
    }

    KV->pmdk_constructor(18,36);//18.36;6:12
   
    char loading_file[100];
    sprintf(loading_file, "%s", "/root/HXY/ubtree/datafile/loadb.csv");
    read_data_from_file(loading_file);
    memset(record, 0, sizeof(record));
    initial = buffer.size();
    struct timeval start_time, end_time;
    uint64_t     time_interval;
    int	worker_thread_num = nb_threads;
    int keys_per_thread = 50000000/nb_threads;
    std::thread threads[128];

    for (int kt = 0; kt < 1; kt++) {
        threads[kt] = std::thread([=]() {
            int start = 0;
            int end = 50000000;
	    auto t = KV->getThreadInfo();
            for (int ii = start; ii < end; ii++) {
                uint64_t k = buffer[ii];
		//printf("%lld\n",k);
                KV->put(k,signextend(k), t);
            }
            });
    }
    for (int t = 0; t < 1; t++) threads[t].join();
  /*
gettimeofday(&start_time, NULL);
for (int kt = 0; kt < worker_thread_num; kt++) {
        threads[kt] = std::thread([=]() {
            auto t = KV->getThreadInfo();
            int start = keys_per_thread * kt;
            int end = start + keys_per_thread;
            for (int ii = start; ii < end; ii++) {
                uint64_t k = buffer[ii];
                static thread_local std::array < uint64_t, 100> results;
                int resultsFound = 0;
                //char op = (char)ops[ii];
                long lend;
                //char op;op = 'i';
		KV->put(k,signextend(k), t);
		}
            });
    }
    for (int t = 0; t < worker_thread_num; t++) threads[t].join();
    gettimeofday(&end_time, NULL);
    time_interval = 1000000 * (end_time.tv_sec - start_time.tv_sec) + end_time.tv_usec - start_time.tv_usec;
    printf("delete time_interval = %lu ns\n", time_interval * 1000);
    printf("average delete op = %lu ns\n", time_interval * 1000 / initial);
    */
      
    printf("load is end\n");
    
    printf("s is %lld\n",sfencenum);
    printf("c is %lld\n",clwbnum);
    printf("a is %lld\n",alloer);
    
sfencenum=0;
clwbnum=0;
alloer=0;

    clear_cache();
    buffer.clear();
    sprintf(loading_file, "%s", "/root/HXY/ubtree/datafile/insert50m.csv");
    //scan_data_from_file(loading_file);
    read_data_from_file(loading_file);
    //sd_data_from_file(loading_file);
    //pcm::PCM * m = pcm::PCM::getInstance();
    //auto status = m->program();
    gettimeofday(&start_time, NULL);
    //pcm::SystemCounterState before_sstate = pcm::getSystemCounterState();
    for (int kt = 0; kt < worker_thread_num; kt++) {
        threads[kt] = std::thread([=]() {
            auto t = KV->getThreadInfo();
            int start = keys_per_thread * kt;
            int end = start + keys_per_thread;
            for (int ii = start; ii < end; ii++) {
                uint64_t k = buffer[ii];
		static thread_local std::array < uint64_t, 100> results;
		int resultsFound = 0;
                //char op = (char)ops[ii];
                long lend;
                char op;op = 'i';
                //lend=slen[ii];
            
              //  if(lend > 0){op='s';}
	//	else{op='i';}
                            
                switch (op)
                {
                case 'r':
		
		    clock_gettime(CLOCK_MONOTONIC, &T1[kt]);
                    KV->lookup(k, t);
		    clock_gettime(CLOCK_MONOTONIC, &T2[kt]);
                    latency[kt] = ((T2[kt].tv_sec - T1[kt].tv_sec) * 1000000000 + (T2[kt].tv_nsec - T1[kt].tv_nsec)) / 100;
                    record[kt][latency[kt]] += 1;
                    insert_nb[kt] += 1;
		    /*
		    clock_gettime(CLOCK_MONOTONIC, &T1);
		    KV->lookup(k, t);
		    clock_gettime(CLOCK_MONOTONIC, &T2);
                    latency = ((T2.tv_sec - T1.tv_sec) * 1000000000 + (T2.tv_nsec - T1.tv_nsec)) / 100;
                    records[latency] += 1;
                    insert_nbs += 1;
		    */
                    break;
                case 'i':
		    
		    clock_gettime(CLOCK_MONOTONIC, &T1[kt]);
                    KV->put(k,signextend(k), t);
		    clock_gettime(CLOCK_MONOTONIC, &T2[kt]);
                    latency[kt] = ((T2[kt].tv_sec - T1[kt].tv_sec) * 1000000000 + (T2[kt].tv_nsec - T1[kt].tv_nsec)) / 100;
                    record[kt][latency[kt]] += 1;
                    insert_nb[kt] += 1;
		    /*
		    clock_gettime(CLOCK_MONOTONIC, &T1);
                    KV->put(k,signextend(k), t);
                    clock_gettime(CLOCK_MONOTONIC, &T2);
                    latency = ((T2.tv_sec - T1.tv_sec) * 1000000000 + (T2.tv_nsec - T1.tv_nsec)) / 100;
                    records[latency] += 1;
                    insert_nbs += 1;
		    */
                    break;
                case 'd':
		    
		    //clock_gettime(CLOCK_MONOTONIC, &T1[kt]);
                    KV->remove(k, t);
		    //clock_gettime(CLOCK_MONOTONIC, &T2[kt]);
                    //latency = ((T2[kt].tv_sec - T1[kt].tv_sec) * 1000000000 + (T2[kt].tv_nsec - T1[kt].tv_nsec)) / 100;
                    //record[kt][latency] += 1;
                    //insert_nb[kt] += 1; 
		    /*
		    clock_gettime(CLOCK_MONOTONIC, &T1);
                    KV->remove(k, t);
                    clock_gettime(CLOCK_MONOTONIC, &T2);
                    latency = ((T2.tv_sec - T1.tv_sec) * 1000000000 + (T2.tv_nsec - T1.tv_nsec)) / 100;
                    records[latency] += 1;
                    insert_nbs += 1;
		    */
		    break;
                case 's':
		    
		    //clock_gettime(CLOCK_MONOTONIC, &T1[kt]);
                    KV->scan(k, UINT64_MAX, lend, results.data(), resultsFound, t);
		    //clock_gettime(CLOCK_MONOTONIC, &T2[kt]);
                    //latency = ((T2[kt].tv_sec - T1[kt].tv_sec) * 1000000000 + (T2[kt].tv_nsec - T1[kt].tv_nsec)) / 100;
                    //record[kt][latency] += 1;
                    //insert_nb[kt] += 1;
		    /*
		    clock_gettime(CLOCK_MONOTONIC, &T1);
                    KV->scan(k, UINT64_MAX, lend, results.data(), resultsFound, t);
                    clock_gettime(CLOCK_MONOTONIC, &T2);
                    latency = ((T2.tv_sec - T1.tv_sec) * 1000000000 + (T2.tv_nsec - T1.tv_nsec)) / 100;
                    records[latency] += 1;
                    insert_nbs += 1;
		    */
                    break;
                default:
                    printf("error\n");
                    break;
                }
            }
            });
    }
    for (int t = 0; t < worker_thread_num; t++) threads[t].join();
    //pcm::SystemCounterState after_sstate = pcm::getSystemCounterState();
    gettimeofday(&end_time, NULL);
    /*
    printf("L3 misses: %lld\n",pcm::getL3CacheMisses(before_sstate, after_sstate));
    printf("DRAM Reads (bytes): %lld\n",pcm::getBytesReadFromMC(before_sstate, after_sstate));
    printf("DRAM Writes (bytes): %lld\n",pcm::getBytesWrittenToMC(before_sstate, after_sstate));
    printf("PM Reads (bytes): %lld\n",pcm::getBytesReadFromPMM(before_sstate, after_sstate));
    printf("PM Writes (bytes): %lld\n",pcm::getBytesWrittenToPMM(before_sstate, after_sstate));
*/
    time_interval = 1000000 * (end_time.tv_sec - start_time.tv_sec) + end_time.tv_usec - start_time.tv_usec;
    printf("delete time_interval = %lu ns\n", time_interval * 1000);
    printf("average delete op = %lu ns\n", time_interval * 1000 / initial);
    
    printf("s is %lld\n",sfencenum);
    printf("c is %lld\n",clwbnum);
    printf("a is %lld\n",alloer);
    

    for(int ik=0;ik<test_thread;ik++)
    {
        for(int jf=0;jf<test_num;jf++)
        {
              if(record[ik][jf] != 0){records[jf]=records[jf] + record[ik][jf];insert_nbs=record[ik][jf]+insert_nbs;}
	}
    }
        uint64_t cnt = 0;
        uint64_t nb_min = insert_nbs * 0.1;
        uint64_t nb_50 = insert_nbs / 2;
        uint64_t nb_90 = insert_nbs * 0.9;
        uint64_t nb_99 = insert_nbs * 0.99;
	uint64_t nb_999 = insert_nbs * 0.999;
	uint64_t nb_9999 = insert_nbs * 0.9999;
        bool flag_50 = false, flag_90 = false, flag_99 = false,flag_min=false,flag_999 = false, flag_9999 = false;
        double latency_50, latency_90, latency_99, latency_min, latency_999, latency_9999;
        for (int i=0; i < 50000000 && !(flag_min && flag_50 && flag_90 && flag_99 && flag_999 && flag_9999); i++){
            cnt += records[i];
            if (!flag_min && cnt >= nb_min){
                latency_min = (double)i / 10.0;
                flag_min = true;
            }
            if (!flag_50 && cnt >= nb_50){
                latency_50 = (double)i / 10.0;
                flag_50 = true;
            }
            if (!flag_90 && cnt >= nb_90){
                latency_90 = (double)i / 10.0;
                flag_90 = true;
            }
            if (!flag_99 && cnt >= nb_99){
                latency_99 = (double)i / 10.0;
                flag_99 = true;
            }
	    if (!flag_999 && cnt >= nb_999){
                latency_999 = (double)i / 10.0;
                flag_999 = true;
            }
	    if (!flag_9999 && cnt >= nb_9999){
                latency_9999 = (double)i / 10.0;
                flag_9999 = true;
            }
        }
        printf("min latency is %.1lfus\nmedium latency is %.1lfus\n90%% latency is %.1lfus\n99%% latency is %.1lfus\n99.9%% latency is %.1lfus\n99.99%% latency is %.1lfus\n", latency_min,latency_50, latency_90, latency_99,latency_999,latency_9999);
    pmemobj_close(pop);
    return ;
}
int main(int argc, char **argv)
{
    run (argc, argv);
    return 0;
}
